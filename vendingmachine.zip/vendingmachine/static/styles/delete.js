// This will handle the product deletion and modal actions

let selectedProductId = null; // Store the ID of the selected product for deletion

// Open the confirmation modal
function confirmDelete(productId) {
  selectedProductId = productId; // Store the selected product ID
  document.getElementById("confirm-modal").style.display = "flex"; // Show the modal
}

// Close the confirmation modal
function closeModal() {
  document.getElementById("confirm-modal").style.display = "none"; // Hide the modal
}

// Delete the selected product
function deleteProduct() {
  if (selectedProductId) {
    const productElement = document.getElementById(selectedProductId); // Get the product element by ID
    productElement.remove(); // Remove it from the DOM (for simplicity)

    // Call your backend API to delete the product from the database
    // Example:
    // fetch('/delete-product', {
    //    method: 'DELETE',
    //    body: JSON.stringify({ productId: selectedProductId }),
    //    headers: { 'Content-Type': 'application/json' }
    // });

    closeModal(); // Close the modal after deletion
  }
}
