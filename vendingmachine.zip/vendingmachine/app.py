from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
import os


app = Flask(__name__)
app.secret_key = 'your_secret_key' 

def get_db_connection():
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='vending_machine'
    )
    return conn


@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session['logged_in'] = True
            session['role'] = 'admin' if user['is_admin'] else 'user'
            session['user_id'] = user['user_id']
            session['username'] = user['username']
            session['full_name'] = user.get('full_name', user['username'])

            return redirect(url_for('home' if user['is_admin'] else 'user_dashboard'))
        else:
            error = "Invalid credentials. Please try again."

    return render_template('login.html', error=error)


@app.route('/admin_dashboard')
def admin_dashboard():
    if 'logged_in' in session and session.get('role') == 'admin':
        return render_template('home.html')
    return redirect(url_for('login'))

@app.route('/user_dashboard')
def user_dashboard():
    if 'logged_in' in session and session.get('role') == 'user':
        return render_template('user_dashboard.html')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

def admin_required(f):
    def wrapper(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@app.route('/home')
@admin_required
def home():
    return render_template('home.html')

@app.route('/product_list')
@admin_required
def product_list():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT * FROM products')
    products = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('product_list.html', products=products)

@app.route('/add_product', methods=['GET', 'POST'])
@admin_required
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        price = request.form['price']
        quantity = request.form['quantity']
        image_url = request.form['image_url']  # Get the image URL from the form

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'INSERT INTO products (name, price, quantity, image_url) VALUES (%s, %s, %s, %s)',
            (name, price, quantity, image_url)
        )
        conn.commit()
        cursor.close()
        conn.close()

        return render_template('add_product.html', message="Product added successfully!")

    return render_template('add_product.html')


@app.route('/update_product', methods=['POST', 'GET'])
@admin_required
def update_product():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    if request.method == 'POST':
        for key in request.form:
            if key.startswith('name_'):
                product_id = key.split('_')[1]
                name = request.form.get(f'name_{product_id}')
                price = request.form.get(f'price_{product_id}')
                quantity = request.form.get(f'quantity_{product_id}')
                image_url = request.form.get(f'image_url_{product_id}')  # ✅ This was missing

                print(f"Updating: product_id={product_id}, Name={name}, Price={price}, Quantity={quantity}, Image URL={image_url}")  # Debug

                cursor.execute(
                    'UPDATE products SET name=%s, price=%s, quantity=%s, image_url=%s WHERE product_id=%s',
                    (name, price, quantity, image_url, product_id)
                )

        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('product_list'))

    cursor.execute('SELECT * FROM products')
    products = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('update_product.html', products=products)

@app.route('/delete_products', methods=['GET', 'POST'])
@admin_required
def delete_products():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    
    if request.method == 'POST':
        product_id = request.form['product_id']
        cursor.execute('DELETE FROM products WHERE product_id = %s', (product_id,))
        conn.commit()
    
    # Fetch all products again to display after deletion
    cursor.execute('SELECT * FROM products')
    products = cursor.fetchall()
    
    cursor.close()
    conn.close()
    
    return render_template('delete_products.html', products=products)

@app.route('/view_products')
def view_products():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)  
    cursor.execute("SELECT product_id, name, price, image_url FROM products")  
    products = cursor.fetchall()

    cursor.close()
    conn.close()

    return render_template('view_products.html', products=products)

@app.route('/buy/<int:product_id>')
def buy_product(product_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT product_id, name, price, quantity, image_url FROM products WHERE product_id = %s", (product_id,))
    product = cursor.fetchone()

    cursor.close()
    conn.close()

    if not product:
        return "Product not found", 404

    return render_template('buy.html', product=product)

@app.route('/confirm_purchase', methods=['POST'])
def confirm_purchase():
    if 'user_id' not in session:
        flash("🚫 You must be logged in to make a purchase.", "error")
        return redirect(url_for('login'))

    user_id = session['user_id']
    product_id = request.form['product_id']
    quantity = int(request.form.get('quantity', 1))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT name, price, quantity AS stock FROM products WHERE product_id = %s", (product_id,))
    product = cursor.fetchone()

    if not product or product['stock'] < quantity:
        flash("❌ Not enough stock available.", "error")
        cursor.close()
        conn.close()
        return redirect(url_for('view_products'))

    cursor.execute("""
        INSERT INTO purchases (user_id, product_id, quantity)
        VALUES (%s, %s, %s)
    """, (user_id, product_id, quantity))

    cursor.execute("""
        UPDATE products SET quantity = quantity - %s WHERE product_id = %s
    """, (quantity, product_id))

    conn.commit()
    cursor.close()
    conn.close()

    total_cost = product['price'] * quantity

    
    return render_template('purchase_success.html', product=product, quantity=quantity, total=total_cost)


@app.route('/purchase_history')
def purchase_history():
    if 'logged_in' not in session or session.get('role') != 'user':
        return redirect(url_for('login'))

    user_id = session.get('user_id')
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
    SELECT 
        p.quantity, 
        p.timestamp, 
        p.payment_mode,
        pr.name AS product_name, 
        pr.image_url, 
        pr.price
    FROM purchases p
    JOIN products pr ON p.product_id = pr.product_id
    WHERE p.user_id = %s
    ORDER BY p.timestamp DESC
""", (user_id,))
    purchases = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('purchase_history.html', purchases=purchases)

def add_to_cart(product_id, quantity):
    if 'cart' not in session:
        session['cart'] = []
    session['cart'].append({'product_id': product_id, 'quantity': quantity})
    session.modified = True

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart_route():
    product_id = int(request.form['product_id'])
    quantity = int(request.form.get('quantity', 1))

    add_to_cart(product_id, quantity)
    flash("🛒 Added to cart!", "success")
    return redirect(url_for('view_products'))

@app.route('/cart')
def view_cart():
    cart = session.get('cart', [])
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cart_items = []
    total_cost = 0

    for item in cart:
        cursor.execute("SELECT * FROM products WHERE product_id = %s", (item['product_id'],))
        product = cursor.fetchone()
        
        
        if not product:
            flash("❌ One or more items in your cart are no longer available.", "error")
            cursor.close()
            conn.close()
            return redirect(url_for('view_products'))

        product['quantity'] = item['quantity']
        product['total_price'] = product['price'] * item['quantity']
        total_cost += product['total_price']
        cart_items.append(product)

    cursor.close()
    conn.close()

    return render_template('cart.html', cart_items=cart_items, total_cost=total_cost)


@app.route('/checkout_cart', methods=['POST'])
def checkout_cart():
    if 'user_id' not in session:
        flash("Please log in to checkout.")
        return redirect(url_for('login'))

    user_id = session['user_id']
    cart = session.get('cart', [])
    if not cart:
        flash("Cart is empty.")
        return redirect(url_for('view_products'))

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cart_items = []
    total_cost = 0

    for item in cart:
        product_id = item['product_id']
        quantity = item['quantity']

        
        cursor.execute("SELECT * FROM products WHERE product_id = %s", (product_id,))
        product = cursor.fetchone()

        if not product or product['quantity'] < quantity:
            flash("Not enough stock for some items.", "error")
            conn.rollback()
            conn.close()
            return redirect(url_for('view_cart'))

        
        cursor.execute(
            "INSERT INTO purchases (user_id, product_id, quantity) VALUES (%s, %s, %s)",
            (user_id, product_id, quantity)
        )

        
        cursor.execute(
            "UPDATE products SET quantity = quantity - %s WHERE product_id = %s",
            (quantity, product_id)
        )

        
        product['purchased_quantity'] = quantity
        product['total_price'] = quantity * product['price']
        total_cost += product['total_price']
        cart_items.append(product)

    conn.commit()
    cursor.close()
    conn.close()

    session['cart'] = []  

    
    return render_template(
        'purchase_success.html',
        cart_items=cart_items,
        total_cost=total_cost
    )

@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    product_id = int(request.form['product_id'])
    cart = session.get('cart', [])

    
    cart = [item for item in cart if item['product_id'] != product_id]
    session['cart'] = cart

    flash("🗑️ Item removed from cart.", "info")
    return redirect(url_for('view_cart'))


@app.route('/account')
def account_settings():
    if 'user_id' not in session:
        flash("Please log in first.", "error")
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute("SELECT full_name, email, profile_pic FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()

    cursor.close()
    conn.close()

    return render_template('account_settings.html', user=user)

@app.route('/account/update_details', methods=['GET', 'POST'])
def update_details():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']

        profile_picture = request.files.get('profile_pic')
        filename = None

        if profile_picture:
            filename = (profile_picture.filename)
            path = os.path.join('static/uploads/', filename)
            profile_picture.save(path)
            cursor.execute("UPDATE users SET full_name = %s, email = %s, profile_pic = %s WHERE user_id = %s",
                           (full_name, email, filename, user_id))
        else:
            cursor.execute("UPDATE users SET full_name = %s, email = %s WHERE user_id = %s",
                           (full_name, email, user_id))

        conn.commit()
        flash("Details updated successfully!", "success")
        return redirect(url_for('account_settings'))

    cursor.execute("SELECT full_name, email FROM users WHERE user_id = %s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return render_template('account/update_details.html', user=user)

@app.route('/account/change_password', methods=['GET', 'POST'])
def change_password():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        current = request.form['current_password']
        new = request.form['new_password']

        user_id = session['user_id']
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)

        cursor.execute("SELECT password FROM users WHERE user_id = %s", (user_id,))
        user = cursor.fetchone()

        if user and user['password'] == current:
            cursor.execute("UPDATE users SET password = %s WHERE user_id = %s", (new, user_id))
            conn.commit()
            flash("Password changed successfully!", "success")
        else:
            flash("Current password is incorrect.", "error")

        cursor.close()
        conn.close()
        return redirect(url_for('change_password'))

    return render_template('account/change_password.html')

@app.route('/account/purchase_insights')
def purchase_insights():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('''
        SELECT p.product_id, pr.name, SUM(p.quantity) as total_quantity, SUM(p.quantity * pr.price) as total_spent
        FROM purchases p
        JOIN products pr ON p.product_id = pr.product_id
        WHERE p.user_id = %s
        GROUP BY p.product_id
    ''', (user_id,))
    purchases = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('account/purchase_insights.html', purchases=purchases)

if __name__ == '__main__':
    app.run(debug=True)
